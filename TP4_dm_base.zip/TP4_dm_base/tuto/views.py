
from .app import app,db
from flask import render_template, url_for, redirect, request, session
from .models import get_sample,get_book_detail,get_author,Author,Book, User, load_user, suppr_book, get_all_book, get_all_author
from flask_login import login_user, current_user,logout_user, login_required
from flask_wtf import FlaskForm
from wtforms import SelectField, PasswordField, StringField, HiddenField, validators, SubmitField
from hashlib import sha256
from werkzeug.security import generate_password_hash
from wtforms.validators import DataRequired


@app.route("/")
def home():
    return render_template("home.html",title="Pseudo Amazon",data=get_sample())

@app.route("/detail/<bookid>")
def detail(bookid):
    return render_template("detail.html",title="Detail",book=get_book_detail(int(bookid)))


#sans validators 
class AuthorForm (FlaskForm):
    id = HiddenField ('id')
    name = StringField ('Nom', [validators.InputRequired(),
    validators.length(min=2,max=25,
    message="le nom doit avoir entre 2 et 25caractères !")
    ])


@app.route("/edit/author/") 
@app.route("/edit/author/<int:id>")
def edit_author(id=None):
    nom=None
    if id is not None:
        a = get_author(id)
        nom=a.name
    else:
        a=None
    f = AuthorForm(id=id, name=nom)
    return render_template("new-author.html", author=a, form=f)

 
@app.route("/save/author/", methods=["POST"])
def save_author():
    a = None
    f = AuthorForm()
    if f.id.data != "":
        id = int(f.id.data)
        a = get_author(id)
    else:
        a = Author(name=f.name.data)
        db.session.add(a)
    if f.validate_on_submit():
        a.name = f.name.data
        db.session.commit()
        id = a.id
        return redirect(url_for('one_author', id=a.id))
    return render_template("new_author.html",author=a, form=f)


@app.route("/author/<int:id>")
def one_author(id):
    auteur=get_author(id)
    return render_template(
        "home.html",
        title="Livre de " + auteur.name,
        data=auteur.books
    )
 #############partie login

class LoginForm(FlaskForm):
    username = StringField('Username')
    password = PasswordField('Password')
    def get_authenticated_user(self):
        user = User.query.get(self.username.data)
        if user is None:
            return None
        m =sha256()
        m.update(self.password.data.encode())
        passwd=m.hexdigest()
        return user if passwd == user.password else None


########################  ---------- LOGIN ET MDP à saisir:::::-----------------

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'Laura' or request.form['password'] != 'Polytech':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('home'))
    return render_template('login.html', error=error)


@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))


####################fin partue faite en cours
class BookForm (FlaskForm):
    author_list =   [(author.name) for author in get_all_author()]
    title = StringField('Title', validators=[DataRequired()])
    picture = StringField('Picture', validators=[DataRequired()])
    price  = StringField('Price', validators=[DataRequired()])
    author = SelectField( 'Author', validators=[DataRequired()], choices=author_list)

    

@app.route("/edit/book/<int:bookid>")
def edit_book(bookid=None):
    f = ModifyForm()
    return render_template("modify.html",form=f)

class ModifyForm(FlaskForm):
    author_list = [(author.name) for author in get_all_author()]
    book_list = [(book.title) for book in get_all_book()]
    author =   SelectField('Author', validators=[DataRequired()],choices=author_list)
    book  =   SelectField('Book Title', validators=[DataRequired()] ,choices=book_list)
    new_title =   StringField('New Book Title', validators=[DataRequired()])
    new_price =   StringField('New Price', validators=[DataRequired()])

@app.route("/save/update/", methods=["POST",])
def save_update():
    f = ModifyForm()
    if f.validate_on_submit():
        new_author     = str(f.author.data)
        new_title      = str(f.book.data)
        new_new_title  = str(f.new_title.data)
        new_new_price  = float(f.new_price.data)
        print('new_author :  {}'.format(new_author), file=sys.stderr)
        print('new_title : {}'.format(new_title),file=sys.stderr)
        print('new_new_title : {}'.format(new_new_title),file=sys.stderr)
        print('new_new_price : {}'.format(new_new_price),file=sys.stderr)
        a = Author.query.filter(Author.name==new_author).one()
        book  =  Book.query.filter(Book.title==new_title).one()
        print('book_list : {}'.format(book), file=sys.stderr)
        if new_new_title != "" and new_new_price != "":
            book.price = new_new_price
            book.title = new_new_title
            db.session.add(book)
            db.session.commit()
        return redirect(url_for('one_author', id=a.id))
    return render_template("modify.html",form=f)


#bon c'est immonde niveau visu mais on voit la liste

####ARTUNG LES REDIRECTIONS########################
@app.route("/add/book/", methods=["GET", "POST"])
def visu_add():
    books = None
    if request.form:
        try:
            book = Book(id=request.form.get("title"))
            db.session.add(book)
            db.session.commit()
        except Exception as e:
            print("Failed to add book")
            print(e)
    books = Book.query.all()
    return render_template("new-book.html", books=books)

@app.route("/add/book", methods=["GET", "POST"]) 
#@login_required
def add_book(bookid=None):
    f = BookForm()
    try:
        newtitle = request.form.get("newtitle")
        oldtitle = request.form.get("oldtitle")
        book = Book.query.filter_by(title=oldtitle).first()
        book.title = newtitle
        db.session.commit()
    except Exception as e:
        print("Couldn't update book title")
        print(e)
    return render_template("add-book.html",form=f)

@app.route("/save/book", methods =["POST"])
def save_book():
    f = BookForm()
    if f.validate_on_submit():
        new_title= str(f.title.data)
        new_picture = str(f.picture.data)
        new_price = float(f.price.data)
        new_author_name  = str(f.author.data)
        print('Title : {}'.format(new_title),file=sys.stderr)
        print('Picture : {}'.format(new_picture),file=sys.stderr)
        print('Price : {}'.format(new_price), file=sys.stderr)
        print('Auteur : {}'.format(new_author_name), file=sys.stderr)
        a = Author.query.filter(Author.name==new_author_name).one()
        book_list   =   [(book.id) for book in get_all_book()]
        print('book_list : {}'.format(max(book_list)), file=sys.stderr)
        if new_title != "" and new_picture != "" and new_price != "" and new_author_name != "":
            b = Book(id = max(book_list)+1,author_id = a.id,author = a,price = new_price,title = new_title,img= new_picture )
            db.session.add(b)
            db.session.commit()
        return redirect(url_for('one_author', id=a.id))
    return render_template("add-book.html",form=f)

class DeleteBookForm(FlaskForm):
    bookin = [(book.title) for book in get_all_book()]
    authorlist = [(author.name) for author in get_all_author()]
    book  =  SelectField('Book Title', validators=[DataRequired()] ,choices=bookin)
    author  = SelectField( 'Author', validators=[DataRequired()] ,choices=authorlist)

@app.route("/delete/book/")
def delete(id=None):
    f = DeleteBookForm()
    return render_template("delete.html",form=f)

   
@app.route("/save/delete/book/", methods=("POST",))
def save_after_delete():
    f = DeleteBookForm()
    if f.validate_on_submit():
        book_title = str(f.book.data)
        book_author_name = str(f.author.data)
        author = Author.query.filter(Author.name==book_author_name).one()
        if book_title != "" and book_author_name != "":
            author = Author.query.filter(Author.name==book_author_name).one()
            Book.query.filter(Book.title==book_title and Book.author==author).delete()
            db.session.commit()
        return redirect(url_for('one_author', id=author.id))
    return render_template("delete.html", form=f)

if __name__ == '__main__':
    app.run(debug=True)
