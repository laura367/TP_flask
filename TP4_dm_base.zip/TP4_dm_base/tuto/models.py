from .app import db, login_manager
from flask_login import UserMixin
from flask_login import UserMixin, LoginManager
from werkzeug.security import generate_password_hash, check_password_hash


class Author(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    name=db.Column(db.String(100))
    def __repr__(self):
        return "<Author (%d) %s>"%(self.id, self.name)

class Book(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    author_id=db.Column(db.Integer,db.ForeignKey("author.id"))
    author=db.relationship("Author",backref=db.backref("books",lazy="dynamic"))
    price=db.Column(db.Float)
    title=db.Column(db.String(100))
    img=db.Column(db.String(256))
    def __repr__(self):
        return "<Book (%d) %s>"%(self.id, self.title)

def get_sample():
    return Book.query.limit(10).all()

def get_book_detail(bookid):
    return Book.query.get_or_404(bookid)
 

def get_author(id):
    return Author.query.get_or_404(id)

def exist_author(name):
    return Author.query.filter(Author.name==name).one()

def get_all_author():
    return Author.query.all()

def get_all_book():
    return Book.query.all()

def suppr_book(bookid):
    contenu = Book.query.get(bookid)
    return db.session.delete(contenu)


class User(db.Model, UserMixin):
    username =db.Column(db.String(50), primary_key=True)
    password = db.Column(db.String(64))
    def get_id(self):
        return self.username
    def set_password(self,password):
        self.password_hash = generate_password_hash(password)
    def check_pasw(self,password):
        return check_pasw_hash(self.password_hash,password)


@login_manager.user_loader
def load_user(username):
     return User.query.get(username)