import click
from .app import app, db
from .models import Author, Book, User, load_user
import yaml
from hashlib import sha256


@app.cli.command()
def syncdb():
    db.create_all()

@app.cli.command()
@click.argument('filename')
def loaddb(filename):
    db.create_all()
    books = yaml.load(open(filename),Loader=yaml.FullLoader)
    authors=dict()
    for b in books:
        a = b["author"]
        if a not in authors:
            obj=Author(name=a)
            db.session.add(obj)
            authors[a]=obj
    db.session.commit()

    for b in books:
        a=authors[b["author"]]
        book=Book(price = b["price"],title=b["title"],img=["img"],author_id=a.id)
        db.session.add(book)
    db.session.commit()

####  login + encryptage mdp mais chétanne 

@app.cli.command()
@click.argument('username')
@click.argument('password')
def newuser(username, password):
    if load_user(username) is not None:
        print("this username already exist, pick another one")
    else:
        m=sha256()
        m.update(password.encode())
        u=User(username=username, password=m.hexdigest())
        db.session.add(u)
        db.session.commit()



@app.cli.command()
@click.argument('username')
@click.argument('password')
def passwd(username, password):
    if load_user(username) is not None:
        m=sha256()
        m.update(password.encode())
        u=load_user(username)
        u.password=m.hexdigest()
        db.session.commit()
    else:
        print("user not found")
    
   