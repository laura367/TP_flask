from flask import Flask

app = Flask(__name__)
from flask_bootstrap import Bootstrap
Bootstrap(app)
app.config['BOOTSTRAP_SERVE_LOCAL'] = True


import os.path
def mkpath(p):
    return os.path.normpath(
    os.path.join(
        os.path.dirname(__file__),
        p
        
    )
)

from flask_sqlalchemy import SQLAlchemy
app.config['SQLALCHEMY_DATABASE_URI']=(
    'sqlite:///'+mkpath('../books.db')
)
app.config['SECRET_KEY'] = "cfa53e52-fbee-11ea-adc1-0242ac120002"
db = SQLAlchemy(app)


from flask_login import LoginManager
login_manager = LoginManager(app)

login_manager.login_view = "login"

if __name__ == '__main__':
    app.run(debug=True)

